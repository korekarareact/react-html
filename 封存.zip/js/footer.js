
var Footer = React.createClass({
  render:function(){
    return (
      <div className="footer">
        <p>Leo Chang's Personal Website</p>
      </div>
    );
  }
});






ReactDOM.render(
  <Footer />,
  document.getElementById('footer')
);
